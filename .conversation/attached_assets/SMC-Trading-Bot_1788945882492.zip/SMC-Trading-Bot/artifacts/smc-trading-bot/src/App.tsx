import { type ReactNode, useEffect, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  Activity,
  AlertTriangle,
  ArrowUpRight,
  BarChart3,
  Bell,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleDot,
  Clock3,
  Crosshair,
  Gauge,
  KeyRound,
  LayoutDashboard,
  LineChart,
  ListFilter,
  LockKeyhole,
  Menu,
  Pause,
  Play,
  Plus,
  Radio,
  RefreshCcw,
  Search,
  Send,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Target,
  Terminal,
  TrendingDown,
  TrendingUp,
  UnlockKeyhole,
  WalletCards,
  X,
  Zap,
} from 'lucide-react';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import {
  getGetBotControlQueryKey,
  getGetTradingAnalysisQueryKey,
  getGetTradingOverviewQueryKey,
  getGetTradingTradeQueryKey,
  getListTradingAlertsQueryKey,
  getListTradingTradesQueryKey,
  useCloseTradingTrade,
  useCreatePaperTrade,
  useGetBotControl,
  useGetTradingAnalysis,
  useGetTradingOverview,
  useGetTradingTrade,
  useListTradingAlerts,
  useListTradingTrades,
  useUpdateBotControl,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();

const navItems = [
  { href: '/', label: 'Overview', icon: LayoutDashboard },
  { href: '/trades', label: 'Trade journal', icon: LineChart },
  { href: '/settings', label: 'Control settings', icon: Settings2 },
];

function formatUsd(value?: number | null) {
  if (value === undefined || value === null || Number.isNaN(value)) return '—';
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 }).format(value);
}

function formatPct(value?: number | null) {
  if (value === undefined || value === null) return '—';
  return `${value.toFixed(1)}%`;
}

function formatTime(value?: string | null) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function formatDate(value?: string | null) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
}

function titleCase(value?: string | null) {
  return (value ?? '').replaceAll('_', ' ').replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function cx(...classes: Array<string | false | undefined>) {
  return classes.filter(Boolean).join(' ');
}

function DataState({ loading, error, empty, onRetry, children }: {
  loading?: boolean;
  error?: boolean;
  empty?: boolean;
  onRetry?: () => void;
  children: ReactNode;
}) {
  if (loading) {
    return <div className="data-state skeleton-state" data-testid="state-loading"><span /><span /><span /></div>;
  }
  if (error) {
    return (
      <div className="data-state" data-testid="state-error">
        <AlertTriangle size={18} />
        <strong>Feed unavailable</strong>
        <span>Could not reach the paper trading service.</span>
        {onRetry && <button className="text-button" onClick={onRetry} data-testid="button-retry">Retry connection</button>}
      </div>
    );
  }
  if (empty) {
    return (
      <div className="data-state" data-testid="state-empty">
        <CircleDot size={18} />
        <strong>No records yet</strong>
        <span>Validated activity will appear here as the bot observes the market.</span>
      </div>
    );
  }
  return <>{children}</>;
}

function StatusPill({ label, tone = 'neutral', dot = false }: { label: string; tone?: 'green' | 'amber' | 'red' | 'blue' | 'neutral'; dot?: boolean }) {
  return <span className={`status-pill ${tone}`} data-testid={`status-${label.toLowerCase().replaceAll(' ', '-')}`}>{dot && <i className="status-dot" />}{label}</span>;
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileNav, setMobileNav] = useState(false);
  const active = navItems.find((item) => item.href === location)?.label ?? 'Overview';

  return (
    <div className="app-shell noise">
      <aside className={cx('sidebar', mobileNav && 'sidebar-open')}>
        <div className="brand-lockup">
          <div className="brand-mark"><span /><span /><span /></div>
          <div><strong>SMC</strong><small>Trading control room</small></div>
        </div>
        <div className="sidebar-section-label">Navigate</div>
        <nav className="side-nav" aria-label="Primary navigation">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = item.href === location;
            return (
              <Link href={item.href} key={item.href} className={cx('side-link', isActive && 'active')} onClick={() => setMobileNav(false)} data-testid={`link-${item.label.toLowerCase().replaceAll(' ', '-')}`}>
                <Icon size={17} strokeWidth={isActive ? 2.5 : 1.8} />
                <span>{item.label}</span>
                {isActive && <ChevronRight size={14} className="side-link-arrow" />}
              </Link>
            );
          })}
        </nav>
        <div className="sidebar-spacer" />
        <div className="discipline-card">
          <ShieldCheck size={17} />
          <div><strong>Discipline protocol</strong><span>Structure before liquidity. Confirmation before entry.</span></div>
        </div>
        <div className="sidebar-foot">
          <div className="connection-line"><i className="status-dot green pulse-dot" /> Paper engine connected</div>
          <span className="mono">v0.8.4 / UTC</span>
        </div>
      </aside>
      {mobileNav && <button className="nav-scrim" aria-label="Close navigation" onClick={() => setMobileNav(false)} data-testid="button-close-navigation" />}
      <main className="main-content">
        <header className="topbar">
          <button className="mobile-menu" onClick={() => setMobileNav(true)} aria-label="Open navigation" data-testid="button-open-navigation"><Menu size={20} /></button>
          <div className="breadcrumb"><span>Workspace</span><ChevronRight size={13} /><strong>{active}</strong></div>
          <div className="topbar-actions">
            <StatusPill label="Paper mode" tone="amber" dot />
            <div className="topbar-divider" />
            <button className="icon-button" aria-label="Notifications" data-testid="button-notifications"><Bell size={17} /><i className="notification-dot" /></button>
            <div className="avatar" data-testid="text-user-avatar">JT</div>
          </div>
        </header>
        <div className="page-wrap">{children}</div>
      </main>
    </div>
  );
}

function PageHeading({ eyebrow, title, description, actions }: { eyebrow: string; title: string; description: string; actions?: ReactNode }) {
  return (
    <div className="page-heading rise-in">
      <div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>
      {actions && <div className="heading-actions">{actions}</div>}
    </div>
  );
}

function MetricCard({ label, value, detail, tone = 'neutral', icon: Icon }: { label: string; value: string; detail: string; tone?: 'green' | 'red' | 'amber' | 'teal' | 'neutral'; icon: typeof Activity }) {
  return (
    <article className={`metric-card ${tone}`} data-testid={`metric-${label.toLowerCase().replaceAll(' ', '-')}`}>
      <div className="metric-top"><span>{label}</span><Icon size={16} /></div>
      <strong>{value}</strong>
      <small>{detail}</small>
    </article>
  );
}

function Dashboard() {
  const overview = useGetTradingOverview();
  const analysis = useGetTradingAnalysis();
  const control = useGetBotControl();
  const alerts = useListTradingAlerts();
  const createTrade = useCreatePaperTrade();
  const qc = useQueryClient();
  const [notice, setNotice] = useState<string | null>(null);
  const data = overview.data;
  const market = analysis.data;
  const latestAlerts = (alerts.data ?? []).slice(0, 4);

  const refreshAll = () => {
    void overview.refetch();
    void analysis.refetch();
    void alerts.refetch();
    void control.refetch();
  };

  const openSetup = () => {
    if (!market) return;
    createTrade.mutate({
      data: {
        side: market.bias === 'short' ? 'short' : 'long',
        entry: market.setup.entry,
        stopLoss: market.setup.stopLoss,
        target: market.setup.target,
        session: market.session,
        setup: market.setup.status,
      },
    }, {
      onSuccess: () => {
        setNotice('Paper position opened from the validated setup.');
        void qc.invalidateQueries({ queryKey: getListTradingTradesQueryKey() });
        void qc.invalidateQueries({ queryKey: getGetTradingOverviewQueryKey() });
        void qc.invalidateQueries({ queryKey: getListTradingAlertsQueryKey() });
      },
      onError: () => setNotice('Setup could not be opened. Review the audit gate and try again.'),
    });
  };

  return (
    <>
      <PageHeading
        eyebrow={`Live workspace / ${data?.symbol ?? 'market feed'}`}
        title="Good process compounds."
        description="A quiet read on structure, liquidity and the risk you have actually taken."
        actions={<button className="secondary-button" onClick={refreshAll} data-testid="button-refresh-dashboard"><RefreshCcw size={15} /> Sync feeds</button>}
      />
      {notice && <div className="notice-banner" data-testid="status-dashboard-notice"><CheckCircle2 size={16} /><span>{notice}</span><button onClick={() => setNotice(null)} aria-label="Dismiss notice" data-testid="button-dismiss-notice"><X size={15} /></button></div>}
      <DataState loading={overview.isLoading && !data} error={overview.isError && !data} onRetry={() => void overview.refetch()}>
        <section className="metric-grid rise-in delay-1">
          <MetricCard label="Net equity" value={formatUsd(data?.equity)} detail={`${data?.mode === 'paper' ? 'Paper account' : 'Live locked'} · synced ${formatTime(data?.lastSync)}`} tone="teal" icon={WalletCards} />
          <MetricCard label="Today P&L" value={formatUsd(data?.todayPnl)} detail={`${data?.todayPnl !== undefined && data.todayPnl >= 0 ? 'Positive session' : 'Loss under review'}`} tone={data?.todayPnl !== undefined && data.todayPnl >= 0 ? 'green' : 'red'} icon={data?.todayPnl !== undefined && data.todayPnl >= 0 ? TrendingUp : TrendingDown} />
          <MetricCard label="Win rate" value={formatPct(data?.winRate)} detail={`${data?.tradesToday ?? 0} of ${data?.maxTradesPerDay ?? 0} daily slots used`} tone="amber" icon={BarChart3} />
          <MetricCard label="Bot state" value={control.data?.running ? 'Running' : 'Paused'} detail={`${titleCase(data?.session)} session · ${data?.exchangeStatus === 'configured' ? 'CoinDCX connected' : 'CoinDCX not configured'}`} tone={control.data?.running ? 'green' : 'neutral'} icon={control.data?.running ? Radio : Pause} />
        </section>
      </DataState>

      <div className="dashboard-grid">
        <section className="panel session-panel rise-in delay-2">
          <div className="panel-heading"><div><div className="eyebrow">Market state</div><h2>{data?.symbol ?? 'BTCUSDT'} / {market?.timeframe ?? '—'}</h2></div><StatusPill label={titleCase(data?.session)} tone="amber" dot /></div>
          <DataState loading={analysis.isLoading && !market} error={analysis.isError && !market} onRetry={() => void analysis.refetch()}>
            <div className="market-readout">
              <div className="market-hero"><span>Directional bias</span><strong className={market?.bias === 'short' ? 'red-text' : 'teal-text'}>{titleCase(market?.bias)}</strong><div className="confidence-track"><span style={{ width: `${Math.min(market?.confidence ?? 0, 100)}%` }} /></div><small>{formatPct(market?.confidence)} confidence / {titleCase(market?.trend)} trend</small></div>
              <div className="range-card"><span>Asian range</span><strong>{market?.asianRange ? `${market.asianRange.low.toLocaleString()} — ${market.asianRange.high.toLocaleString()}` : '—'}</strong><StatusPill label={market?.asianRange?.status ?? 'Pending'} tone={market?.asianRange?.status === 'swept' ? 'blue' : 'neutral'} /></div>
            </div>
            <div className="market-columns">
              <ReadoutList title="Structure" icon={BarChart3} items={market?.structure ?? []} tone="teal" />
              <ReadoutList title="Liquidity" icon={Crosshair} items={market?.liquidity ?? []} tone="amber" />
              <ReadoutList title="Invalidation" icon={AlertTriangle} items={market?.invalidation ?? []} tone="red" />
            </div>
            <div className="checked-line"><Clock3 size={14} /> Analysis checked {formatTime(market?.checkedAt)} · {market?.session ? titleCase(market.session) : 'Session pending'}</div>
          </DataState>
        </section>

        <section className="panel setup-panel rise-in delay-3">
          <div className="panel-heading"><div><div className="eyebrow">Validated setup</div><h2>Entry gate</h2></div><Target size={18} className="panel-icon" /></div>
          <DataState loading={analysis.isLoading && !market} error={analysis.isError && !market} onRetry={() => void analysis.refetch()}>
            <div className="setup-status"><span className="setup-status-mark"><Check size={19} /></span><div><strong>{titleCase(market?.setup?.status ?? 'Awaiting scan')}</strong><span>All required confluences recorded</span></div></div>
            <div className="price-ladder">
              <div><span>Target</span><strong className="teal-text">{market?.setup ? market.setup.target.toLocaleString() : '—'}</strong></div>
              <div className="ladder-line"><i /><i /><i /></div>
              <div><span>Entry</span><strong>{market?.setup ? market.setup.entry.toLocaleString() : '—'}</strong></div>
              <div className="ladder-line danger"><i /><i /><i /></div>
              <div><span>Stop loss</span><strong className="red-text">{market?.setup ? market.setup.stopLoss.toLocaleString() : '—'}</strong></div>
            </div>
            <div className="rr-row"><span>Risk / reward</span><strong>1 : {market?.setup?.riskReward ?? '—'}</strong></div>
            <button className="primary-button full-button" disabled={!market?.setup || createTrade.isPending} onClick={openSetup} data-testid="button-open-paper-trade"><Plus size={16} /> {createTrade.isPending ? 'Opening position…' : 'Open paper position'}</button>
            <p className="microcopy"><ShieldCheck size={13} /> Paper only. Live orders remain locked in control settings.</p>
          </DataState>
        </section>
      </div>

      <div className="lower-grid">
        <section className="panel alerts-panel rise-in delay-3">
          <div className="panel-heading"><div><div className="eyebrow">Audit trail</div><h2>Recent alerts</h2></div><Link href="/trades" className="panel-link" data-testid="link-view-trades">View journal <ChevronRight size={14} /></Link></div>
          <DataState loading={alerts.isLoading && !alerts.data} error={alerts.isError && !alerts.data} empty={!alerts.isLoading && !alerts.isError && latestAlerts.length === 0} onRetry={() => void alerts.refetch()}>
            <div className="alert-list">{latestAlerts.map((alert) => <AlertRow key={alert.id} alert={alert} />)}</div>
          </DataState>
        </section>
        <section className="protocol-card rise-in delay-4">
          <div className="protocol-number">01</div><div className="eyebrow">SMC operating system</div><h2>Structure first.<br />Liquidity next.</h2>
          <div className="protocol-steps"><span className="done"><Check size={13} /> Structure</span><span className="done"><Check size={13} /> Liquidity</span><span><CircleDot size={13} /> Confirmation</span><span><CircleDot size={13} /> Entry</span></div>
          <p>Every loss gets an explanation. No exceptions, no revenge trades.</p>
          <Link href="/settings" className="protocol-link" data-testid="link-protocol-settings">Review risk controls <ArrowUpRight size={14} /></Link>
        </section>
      </div>
    </>
  );
}

function ReadoutList({ title, icon: Icon, items, tone }: { title: string; icon: typeof BarChart3; items: string[]; tone: 'teal' | 'amber' | 'red' }) {
  return <div className="readout-list"><div className={`readout-title ${tone}`}><Icon size={14} /> {title}</div>{items.length ? items.map((item, index) => <div className="readout-item" key={`${item}-${index}`}><i />{item}</div>) : <div className="readout-item muted">Awaiting confirmation</div>}</div>;
}

function AlertRow({ alert }: { alert: { id: number; type: string; title: string; body: string; status: string; createdAt: string } }) {
  const tone = alert.type === 'audit' || alert.type === 'system' ? 'amber' : alert.type === 'trade_closed' ? 'teal' : 'blue';
  return <div className="alert-row" data-testid={`alert-row-${alert.id}`}><div className={`alert-icon ${tone}`}><Bell size={14} /></div><div className="alert-copy"><strong>{alert.title}</strong><span>{alert.body}</span></div><div className="alert-meta"><StatusPill label={titleCase(alert.status)} tone={alert.status === 'failed' ? 'red' : alert.status === 'sent' ? 'green' : 'neutral'} /><small>{formatTime(alert.createdAt)}</small></div></div>;
}

function Trades() {
  const [status, setStatus] = useState<'all' | 'open' | 'won' | 'lost' | 'rejected'>('all');
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const query = useListTradingTrades(status === 'all' ? undefined : { status });
  const trades = query.data ?? [];
  const filtered = useMemo(() => trades.filter((trade) => `${trade.symbol} ${trade.setup} ${trade.session} ${trade.audit.verdict}`.toLowerCase().includes(search.toLowerCase())), [trades, search]);

  return (
    <>
      <PageHeading eyebrow="Journal / execution ledger" title="Every trade leaves a trace." description="Search the paper book, inspect the audit, and close open risk without losing the reason." actions={<button className="secondary-button" onClick={() => void query.refetch()} data-testid="button-refresh-trades"><RefreshCcw size={15} /> Refresh journal</button>} />
      <section className="journal-toolbar rise-in delay-1">
        <div className="search-field"><Search size={16} /><input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search symbol, setup or verdict" data-testid="input-search-trades" /></div>
        <div className="filter-tabs" role="tablist">{(['all', 'open', 'won', 'lost', 'rejected'] as const).map((item) => <button key={item} className={cx(status === item && 'active')} onClick={() => setStatus(item)} role="tab" aria-selected={status === item} data-testid={`filter-trades-${item}`}><span className={`filter-dot ${item}`} />{titleCase(item)}</button>)}</div>
        <div className="toolbar-count"><ListFilter size={15} /> {filtered.length} records</div>
      </section>
      <section className="panel journal-panel rise-in delay-2">
        <DataState loading={query.isLoading} error={query.isError} empty={!query.isLoading && !query.isError && filtered.length === 0} onRetry={() => void query.refetch()}>
          <div className="trade-table-wrap">
            <table className="trade-table"><thead><tr><th>Trade</th><th>State</th><th>Entry / exit</th><th>Risk / reward</th><th>P&L</th><th>Audit</th><th /></tr></thead><tbody>{filtered.map((trade) => <TradeRow key={trade.id} trade={trade} onSelect={() => setSelectedId(trade.id)} />)}</tbody></table>
          </div>
        </DataState>
      </section>
      {selectedId !== null && <TradeDrawer tradeId={selectedId} onClose={() => setSelectedId(null)} />}
    </>
  );
}

function TradeRow({ trade, onSelect }: { trade: any; onSelect: () => void }) {
  const positive = (trade.pnl ?? 0) >= 0;
  return <tr className="trade-row" onClick={onSelect} data-testid={`row-trade-${trade.id}`}><td><div className="trade-main"><span className={`side-marker ${trade.side}`} /> <div><strong>{trade.symbol}</strong><small>{titleCase(trade.session)} · {trade.setup}</small></div></div></td><td><StatusPill label={titleCase(trade.status)} tone={trade.status === 'won' ? 'green' : trade.status === 'lost' ? 'red' : trade.status === 'open' ? 'blue' : 'neutral'} dot /></td><td><div className="table-prices"><span>{trade.entry.toLocaleString()}</span><small>{trade.exit ? trade.exit.toLocaleString() : 'Open'}</small></div></td><td className="mono">1 : {trade.riskReward}</td><td className={cx('pnl-cell mono', positive ? 'teal-text' : 'red-text')}>{trade.pnl === null || trade.pnl === undefined ? 'Open' : `${positive ? '+' : ''}${formatUsd(trade.pnl)}`}</td><td><span className={`audit-grade grade-${String(trade.audit.grade).toLowerCase().replaceAll(' ', '-')}`}>{trade.audit.grade}</span><small className="audit-verdict">{trade.audit.verdict}</small></td><td><ChevronRight size={16} className="row-chevron" /></td></tr>;
}

function TradeDrawer({ tradeId, onClose }: { tradeId: number; onClose: () => void }) {
  const qc = useQueryClient();
  const query = useGetTradingTrade(tradeId, { query: { enabled: Boolean(tradeId), queryKey: getGetTradingTradeQueryKey(tradeId) } });
  const closeTrade = useCloseTradingTrade();
  const [exit, setExit] = useState('');
  const [verdict, setVerdict] = useState('');
  const trade = query.data;

  const submitClose = () => {
    if (!exit || !verdict) return;
    closeTrade.mutate({ tradeId, data: { exit: Number(exit), verdict } }, {
      onSuccess: () => {
        void qc.invalidateQueries({ queryKey: getListTradingTradesQueryKey() });
        void qc.invalidateQueries({ queryKey: getGetTradingTradeQueryKey(tradeId) });
        void qc.invalidateQueries({ queryKey: getGetTradingOverviewQueryKey() });
        onClose();
      },
    });
  };

  return <div className="drawer-scrim" onClick={onClose}><aside className="trade-drawer" onClick={(event) => event.stopPropagation()}><div className="drawer-top"><div><div className="eyebrow">Trade audit / #{tradeId}</div><h2>{trade?.symbol ?? 'Loading trade'}</h2></div><button className="icon-button" onClick={onClose} aria-label="Close trade details" data-testid="button-close-trade-drawer"><X size={18} /></button></div><DataState loading={query.isLoading} error={query.isError} onRetry={() => void query.refetch()}>{trade && <><div className="drawer-status"><StatusPill label={titleCase(trade.status)} tone={trade.status === 'won' ? 'green' : trade.status === 'lost' ? 'red' : trade.status === 'open' ? 'blue' : 'neutral'} dot /><span>{formatDate(trade.openedAt)} · {titleCase(trade.session)}</span></div><div className="drawer-grid">{[['Entry', trade.entry.toLocaleString()], ['Stop loss', trade.stopLoss.toLocaleString()], ['Target', trade.target.toLocaleString()], ['R:R', `1 : ${trade.riskReward}`]].map(([label, value]) => <div key={label}><span>{label}</span><strong>{value}</strong></div>)}</div><div className="drawer-section"><div className="drawer-label">Confluences</div><div className="tag-list">{trade.confluences.map((item: string) => <span key={item}>{item}</span>)}</div></div><div className="drawer-section"><div className="drawer-label">Audit / {trade.audit.grade}</div><p className="audit-verdict-large">{trade.audit.verdict}</p><ul className="reason-list">{trade.audit.reasons.map((reason: string) => <li key={reason}><Check size={14} />{reason}</li>)}</ul><div className="checklist">{trade.audit.checklist.map((item: { label: string; passed: boolean }) => <div key={item.label} className={item.passed ? 'passed' : 'failed'}>{item.passed ? <CheckCircle2 size={14} /> : <AlertTriangle size={14} />}<span>{item.label}</span></div>)}</div></div>{trade.status === 'open' && <div className="close-trade-box"><div className="drawer-label">Close open risk</div><div className="form-row"><label>Exit price<input value={exit} onChange={(event) => setExit(event.target.value)} type="number" placeholder="e.g. 68420.50" data-testid="input-trade-exit" /></label><label>Verdict<input value={verdict} onChange={(event) => setVerdict(event.target.value)} placeholder="What did price confirm?" data-testid="input-trade-verdict" /></label></div><button className="primary-button full-button" disabled={!exit || !verdict || closeTrade.isPending} onClick={submitClose} data-testid="button-close-trade">{closeTrade.isPending ? 'Writing audit…' : 'Close and write audit'}</button></div>}</>}</DataState></aside></div>;
}

function Settings() {
  const control = useGetBotControl();
  const update = useUpdateBotControl();
  const qc = useQueryClient();
  const [running, setRunning] = useState(false);
  const [maxTrades, setMaxTrades] = useState('3');
  const [risk, setRisk] = useState('0.5');
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    if (control.data) {
      setRunning(control.data.running);
      setMaxTrades(String(control.data.maxTradesPerDay));
      setRisk(String(control.data.riskPerTrade));
    }
  }, [control.data]);

  const save = () => {
    update.mutate({ data: { running, maxTradesPerDay: Number(maxTrades), riskPerTrade: Number(risk) } }, {
      onSuccess: (next) => {
        setRunning(next.running);
        setNotice('Runtime controls saved to the paper engine.');
        void qc.invalidateQueries({ queryKey: getGetBotControlQueryKey() });
        void qc.invalidateQueries({ queryKey: getGetTradingOverviewQueryKey() });
      },
      onError: () => setNotice('Controls were not saved. Check the allowed limits.'),
    });
  };

  const current = control.data;
  return <>
    <PageHeading eyebrow="Control room / constraints" title="Make risk boring." description="Runtime controls are deliberately narrow. The bot can only act inside the guardrails you can explain." actions={<button className="primary-button" onClick={save} disabled={update.isPending || control.isLoading} data-testid="button-save-settings"><Check size={15} /> {update.isPending ? 'Saving…' : 'Save controls'}</button>} />
    {notice && <div className="notice-banner" data-testid="status-settings-notice"><CheckCircle2 size={16} /><span>{notice}</span><button onClick={() => setNotice(null)} aria-label="Dismiss notice" data-testid="button-dismiss-settings-notice"><X size={15} /></button></div>}
    <DataState loading={control.isLoading} error={control.isError} onRetry={() => void control.refetch()}>
      <div className="settings-grid rise-in delay-1">
        <section className="panel settings-main"><div className="panel-heading"><div><div className="eyebrow">Runtime</div><h2>Bot controls</h2></div><Gauge size={18} className="panel-icon" /></div><div className="control-list">
          <div className="control-row"><div className="control-label"><span className="control-icon teal-bg"><Play size={15} /></span><div><strong>Paper engine</strong><small>Allow the strategy to open paper positions</small></div></div><button className={cx('toggle', running && 'on')} onClick={() => setRunning(!running)} role="switch" aria-checked={running} data-testid="switch-bot-running"><span /></button></div>
          <div className="control-row"><div className="control-label"><span className="control-icon amber-bg"><ListFilter size={15} /></span><div><strong>Max trades per day</strong><small>Stops new entries after the daily cap</small></div></div><div className="inline-input"><input value={maxTrades} onChange={(event) => setMaxTrades(event.target.value)} type="number" min="1" max="5" data-testid="input-max-trades" /><span>trades</span></div></div>
          <div className="control-row"><div className="control-label"><span className="control-icon red-bg"><ShieldCheck size={15} /></span><div><strong>Risk per trade</strong><small>Position risk as a percentage of equity</small></div></div><div className="inline-input"><input value={risk} onChange={(event) => setRisk(event.target.value)} type="number" min="0.1" max="2" step="0.1" data-testid="input-risk-per-trade" /><span>%</span></div></div>
        </div><div className="limit-note"><LockKeyhole size={14} /><span>Hard limits: 1–5 trades/day · 0.1–2% risk/trade</span></div></section>

        <section className="panel settings-side"><div className="panel-heading"><div><div className="eyebrow">Execution gate</div><h2>Paper / live lock</h2></div><LockKeyhole size={18} className="panel-icon" /></div><div className="mode-lock"><div className="mode-symbol"><LockKeyhole size={21} /></div><div><strong>{titleCase(current?.mode ?? 'paper')}</strong><span>Live orders are not enabled</span></div><StatusPill label="Locked" tone="amber" /></div><p className="settings-copy">This workspace is paper-first by design. Live order permissions cannot be changed from the dashboard.</p><div className="locked-row"><span><UnlockKeyhole size={14} /> Live orders</span><strong>{current?.liveOrdersEnabled ? 'Enabled' : 'Disabled'}</strong></div><div className="locked-row"><span><Terminal size={14} /> Instrument</span><strong>{current?.symbol ?? '—'}</strong></div></section>

        <section className="panel sessions-panel"><div className="panel-heading"><div><div className="eyebrow">Session map</div><h2>Allowed sessions</h2></div><SlidersHorizontal size={18} className="panel-icon" /></div><p className="settings-copy">Entries are only considered when the session has enough liquidity to honor the model.</p><div className="session-options">{['asian', 'london', 'new_york'].map((session) => <div key={session} className={cx('session-option', current?.sessions.includes(session) && 'selected')}><span className="session-marker" /><div><strong>{titleCase(session)}</strong><small>{session === 'asian' ? 'Range formation' : session === 'london' ? 'Expansion window' : 'Continuation window'}</small></div>{current?.sessions.includes(session) && <CheckCircle2 size={16} />}</div>)}</div><div className="limit-note"><LockKeyhole size={14} /><span>Session map is strategy-managed and read-only</span></div></section>

        <section className="panel telegram-panel"><div className="panel-heading"><div><div className="eyebrow">Connections</div><h2>Exchange & Telegram</h2></div><Send size={18} className="panel-icon" /></div><div className={cx('telegram-status', current?.exchangeStatus === 'configured' && 'ready')}><div className="telegram-mark"><Terminal size={17} /></div><div><strong>{current?.exchangeStatus === 'configured' ? 'CoinDCX configured' : 'CoinDCX not configured'}</strong><span>{current?.exchangeStatus === 'configured' ? 'Credentials are available securely to the paper runner.' : 'Add credentials in Replit Secrets.'}</span></div></div><div className={cx('telegram-status', current?.telegramStatus === 'ready' && 'ready')}><div className="telegram-mark"><Send size={17} /></div><div><strong>{current?.telegramStatus === 'ready' ? 'Telegram ready' : 'Telegram not configured'}</strong><span>{current?.telegramStatus === 'ready' ? 'Trade and audit alerts will be delivered.' : 'Connect a bot token to receive alerts.'}</span></div></div><button className="secondary-button full-button" disabled data-testid="button-configure-telegram"><KeyRound size={15} /> Configure in environment</button></section>
      </div>
    </DataState>
  </>;
}

function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Switch><Route path="/" component={Dashboard} /><Route path="/trades" component={Trades} /><Route path="/settings" component={Settings} /><Route component={NotFound} /></Switch></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Shell><Router /></Shell></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;