# SMC Trading Bot

Paper-first BTC/USDT SMC trading control room with session filters, risk guardrails, trade journaling, and rule-by-rule trade audits.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server
- `pnpm --filter @workspace/smc-trading-bot run dev` — run the dashboard
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — managed PostgreSQL connection

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- Frontend: React + Vite
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval
- SMC engine: Python standard library

## Where things live

- `artifacts/smc-trading-bot/` — responsive dashboard for overview, trade journal, and control settings.
- `artifacts/api-server/src/routes/trading.ts` — trading API, paper-trade mutations, and audit responses.
- `lib/api-spec/openapi.yaml` — source of truth for the API contract.
- `lib/db/src/schema/trading.ts` — PostgreSQL tables for trades, alerts, and bot controls.
- `bot/smc_engine.py` — deterministic SMC analysis and trade-audit primitives.
- `bot/run_bot.py` — paper-first runner and optional Telegram adapter.

## Architecture decisions

- Paper mode is the only execution mode in the first build; live orders are hard-locked at the API and dashboard level.
- A setup is valid only after trend read, Asian-range liquidity sweep, BOS/CHoCH displacement, FVG, session, and risk/reward checks.
- Telegram remains `not_configured` until secure credentials are provided; no credential is read from uploaded screenshots.
- Every closed trade carries a structured audit with a grade, verdict, reasons, and checklist.

## Product

The dashboard shows BTC/USDT market structure, London/New York session state, Asian range, validated paper setups, equity/P&L, alerts, and bot controls. The journal keeps open/won/lost trades and explains why a losing trade violated the SMC process.

## User preferences

- Keep the bot paper-first until the SMC rules are validated on historical and live paper data.
- Never paste exchange credentials or Telegram tokens into chat or commit them to code.

## Gotchas

- Run `pnpm --filter @workspace/api-spec run codegen` after changing `lib/api-spec/openapi.yaml`.
- Re-run `pnpm --filter @workspace/db run push` after changing the Drizzle schema.
- The API workflow requires the managed PostgreSQL database.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.